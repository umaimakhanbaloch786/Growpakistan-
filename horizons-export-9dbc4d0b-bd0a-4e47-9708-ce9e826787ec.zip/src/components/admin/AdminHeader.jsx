import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { LogOut, Shield } from 'lucide-react';

const AdminHeader = ({ onLogout }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="flex justify-between items-center mb-8"
    >
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center">
          <Shield className="h-8 w-8 mr-3 text-blue-400" />
          Admin Dashboard
        </h1>
        <p className="text-white/70">Grow Pakistan Management Panel</p>
      </div>
      <Button onClick={onLogout} variant="outline" className="border-white/20 text-white hover:bg-white hover:text-blue-900">
        <LogOut className="h-4 w-4 mr-2" />
        Logout
      </Button>
    </motion.div>
  );
};

export default AdminHeader;