import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, DollarSign, TrendingUp, ArrowDownLeft, Gift, AlertTriangle } from 'lucide-react';

const AdminStatCards = ({ stats }) => {
  const cardData = [
    { title: "Total Users", value: stats.totalUsers, icon: Users, color: "text-blue-400" },
    { title: "Total Invested", value: `PKR ${stats.totalInvestments.toLocaleString()}`, icon: DollarSign, color: "text-green-400" },
    { title: "Pending Investments", value: stats.pendingInvestments, icon: AlertTriangle, color: "text-yellow-400" },
    { title: "Pending Withdrawals", value: stats.pendingWithdrawals, icon: AlertTriangle, color: "text-orange-400" },
    { title: "Referral Bonuses Paid", value: `PKR ${stats.totalReferralBonuses.toLocaleString()}`, icon: Gift, color: "text-red-400" },
    { title: "Admin Earnings", value: `PKR ${stats.adminEarnings.toLocaleString()}`, icon: TrendingUp, color: "text-purple-400" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.1 }}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8"
    >
      {cardData.map((card, index) => (
        <Card key={index} className="glass-effect border-white/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white/70">{card.title}</CardTitle>
            <card.icon className={`h-4 w-4 ${card.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{card.value}</div>
          </CardContent>
        </Card>
      ))}
    </motion.div>
  );
};

export default AdminStatCards;