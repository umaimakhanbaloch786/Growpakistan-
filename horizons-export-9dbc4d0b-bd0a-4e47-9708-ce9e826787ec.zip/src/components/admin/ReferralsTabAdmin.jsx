import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Gift } from 'lucide-react';

const ReferralsTabAdmin = ({ users }) => {
  return (
    <Card className="glass-effect border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Gift className="h-5 w-5 mr-2 text-red-400" />
          Referral System Overview
        </CardTitle>
        <CardDescription className="text-white/70">
          Monitor referral activities and bonuses across the platform.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 max-h-[60vh] overflow-y-auto scrollbar-hide">
        {users.filter(user => user.referrals && user.referrals.length > 0).map((user) => (
          <div key={user.id} className="p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="mb-3">
              <p className="text-white font-medium">{user.name}</p>
              <p className="text-white/60 text-sm">
                Code: {user.referralCode} • Total Earnings: PKR {user.referralEarnings.toLocaleString()}
              </p>
            </div>
            <div className="space-y-2">
              {user.referrals.map((referral, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-white/5 rounded">
                  <p className="text-white text-sm">{referral.name}</p>
                  <p className="text-white/60 text-xs">
                    Joined: {new Date(referral.joinDate).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default ReferralsTabAdmin;