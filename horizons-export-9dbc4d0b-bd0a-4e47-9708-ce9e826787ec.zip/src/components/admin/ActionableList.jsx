import React from 'react';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';

const ActionableListItem = ({ item, type, onAction }) => {
  const isInvestment = type === 'investments';
  const statusColors = {
    approved: 'bg-green-500/20 text-green-400',
    rejected: 'bg-red-500/20 text-red-400',
    pending: 'bg-yellow-500/20 text-yellow-400',
  };

  return (
    <div className="p-4 bg-white/5 rounded-lg border border-white/10">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1">
          <div>
            <p className="text-white font-medium">{item.userName}</p>
            <p className="text-white/60 text-sm">{item.userEmail}</p>
          </div>
          <div>
            <p className="text-white font-medium">PKR {item.amount.toLocaleString()}</p>
            <p className="text-white/60 text-sm">
              {new Date(item.date).toLocaleString()}
              {!isInvestment && ` • ${item.method}`}
            </p>
          </div>
          <div className="flex items-center gap-4">
             {isInvestment && item.screenshot && <img-replace src={item.screenshot} alt="screenshot" className="h-12 w-12 rounded object-cover cursor-pointer" onClick={() => window.open(item.screenshot)}/>}
            <span className={`px-3 py-1 rounded-full text-sm ${statusColors[item.status]}`}>
              {item.status}
            </span>
          </div>
        </div>
        {item.status === 'pending' && (
          <div className="flex space-x-2">
            <Button size="sm" onClick={() => onAction(item.userId, item.id, 'approved')} className="bg-green-600 hover:bg-green-700 text-white">
              <Check className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="destructive" onClick={() => onAction(item.userId, item.id, 'rejected')}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

const ActionableList = ({ items, type, onAction }) => (
  <div className="space-y-4 max-h-[60vh] overflow-y-auto scrollbar-hide">
    {items.length > 0 ? items.map((item) => (
      <ActionableListItem key={`${item.userId}-${item.id}`} item={item} type={type} onAction={onAction} />
    )) : <p className="text-white/60 text-center py-8">No {type} found.</p>}
  </div>
);

export default ActionableList;