import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Users } from 'lucide-react';

const UsersTab = ({ users }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.referralCode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="glass-effect border-white/20">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-white flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-400" />
              All Users
            </CardTitle>
            <CardDescription className="text-white/70">
              View and manage all registered users.
            </CardDescription>
          </div>
          <Input 
            type="text"
            placeholder="Search by name, email, or code..."
            className="w-64 bg-white/10 border-white/20 text-white placeholder:text-white/50"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4 max-h-[60vh] overflow-y-auto scrollbar-hide">
        {filteredUsers.map((user) => (
          <div key={user.id} className="p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-white">
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-white/60">{user.email}</p>
                <p className="text-sm text-white/60">Code: {user.referralCode}</p>
              </div>
              <div>
                <p className="text-sm text-white/70">Balance</p>
                <p>PKR {user.currentBalance.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-white/70">Total Invested</p>
                <p>PKR {user.totalInvestment.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-white/70">Referral Earnings</p>
                <p>PKR {user.referralEarnings.toLocaleString()}</p>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default UsersTab;