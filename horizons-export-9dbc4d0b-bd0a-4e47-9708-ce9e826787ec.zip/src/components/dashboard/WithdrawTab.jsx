import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowDownLeft } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const WithdrawTab = ({ currentBalance, onWithdraw }) => {
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('jazzcash');
  const { toast } = useToast();

  const handleWithdrawal = () => {
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount < 3) {
      toast({ title: "Invalid Amount", description: "Minimum withdrawal is PKR 3.", variant: "destructive" });
      return;
    }
    if (amount > currentBalance) {
      toast({ title: "Insufficient Balance", description: "You cannot withdraw more than your current balance.", variant: "destructive" });
      return;
    }
    onWithdraw(amount, withdrawMethod);
    setWithdrawAmount('');
  };

  return (
    <Card className="glass-effect border-white/20 max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <ArrowDownLeft className="h-5 w-5 mr-2 text-green-400" />
          Withdraw Funds
        </CardTitle>
        <CardDescription className="text-white/70">
          Request withdrawal to your preferred method. Minimum PKR 3.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="withdrawAmount" className="text-white">Withdrawal Amount (PKR)</Label>
          <Input
            id="withdrawAmount"
            type="number"
            placeholder="Enter amount"
            value={withdrawAmount}
            onChange={(e) => setWithdrawAmount(e.target.value)}
            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-white">Withdrawal Method</Label>
          <div className="space-y-2">
            <label className="flex items-center space-x-2 text-white">
              <input
                type="radio"
                value="jazzcash"
                checked={withdrawMethod === 'jazzcash'}
                onChange={(e) => setWithdrawMethod(e.target.value)}
                className="text-orange-400"
              />
              <span>JazzCash - 03447230855 (Maria Shaheen)</span>
            </label>
            <label className="flex items-center space-x-2 text-white">
              <input
                type="radio"
                value="easypaisa"
                checked={withdrawMethod === 'easypaisa'}
                onChange={(e) => setWithdrawMethod(e.target.value)}
                className="text-blue-400"
              />
              <span>Easypaisa - 03401070881 (Muhammad Ishfaq)</span>
            </label>
          </div>
        </div>
        <Button onClick={handleWithdrawal} className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold">
          Request Withdrawal
        </Button>
      </CardContent>
    </Card>
  );
};

export default WithdrawTab;