import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';

const HistoryItem = ({ item, type }) => {
  const isInvestment = type === 'investment';
  const statusColors = {
    approved: 'bg-green-500/20 text-green-400',
    rejected: 'bg-red-500/20 text-red-400',
    pending: 'bg-yellow-500/20 text-yellow-400',
  };

  return (
    <div className="p-4 bg-white/5 rounded-lg border border-white/10 flex justify-between items-center">
      <div>
        <p className="text-white font-medium">PKR {item.amount.toLocaleString()}</p>
        <p className="text-white/60 text-sm">
          {new Date(item.date).toLocaleDateString()}
          {isInvestment ? ` • ${item.plan}% daily (fake)` : ` • ${item.method}`}
        </p>
      </div>
      <div className="flex items-center gap-4">
        {isInvestment && item.screenshot && <img-replace src={item.screenshot} alt="screenshot" className="h-10 w-10 rounded object-cover cursor-pointer" onClick={() => window.open(item.screenshot)}/>}
        <span className={`px-3 py-1 rounded-full text-sm ${statusColors[item.status]}`}>
          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
        </span>
      </div>
    </div>
  );
};


const HistoryTab = ({ investments, withdrawals }) => {
  return (
    <div className="space-y-6">
      <Card className="glass-effect border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <ArrowUpRight className="h-5 w-5 mr-2 text-green-400" />
            Investment History
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 max-h-96 overflow-y-auto scrollbar-hide">
          {investments.length > 0 ? (
            [...investments].reverse().map((item, index) => <HistoryItem key={index} item={item} type="investment" />)
          ) : (
            <p className="text-white/60 text-center py-8">No investments yet.</p>
          )}
        </CardContent>
      </Card>

      <Card className="glass-effect border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <ArrowDownLeft className="h-5 w-5 mr-2 text-red-400" />
            Withdrawal History
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 max-h-96 overflow-y-auto scrollbar-hide">
          {withdrawals.length > 0 ? (
            [...withdrawals].reverse().map((item, index) => <HistoryItem key={index} item={item} type="withdrawal" />)
          ) : (
            <p className="text-white/60 text-center py-8">No withdrawals yet.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default HistoryTab;