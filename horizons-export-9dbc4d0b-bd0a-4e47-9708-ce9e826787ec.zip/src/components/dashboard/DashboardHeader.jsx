import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';

const DashboardHeader = ({ userName, onLogout }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="flex flex-col sm:flex-row justify-between sm:items-center mb-8 gap-4"
    >
      <div>
        <h1 className="text-3xl font-bold text-white">Welcome, {userName}!</h1>
        <p className="text-white/70">Your Grow Pakistan Dashboard</p>
      </div>
      <Button onClick={onLogout} variant="outline" className="border-white/20 text-white hover:bg-white hover:text-blue-900">
        <LogOut className="h-4 w-4 mr-2" />
        Logout
      </Button>
    </motion.div>
  );
};

export default DashboardHeader;