import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Wallet, TrendingUp, DollarSign, Gift } from 'lucide-react';

const StatCards = ({ stats }) => {
  const cardData = [
    { title: "Current Balance", value: stats.currentBalance, icon: Wallet, color: "text-blue-400" },
    { title: "Current Income", value: stats.currentIncome, icon: TrendingUp, color: "text-green-400" },
    { title: "Total Income", value: stats.totalEarnings, icon: DollarSign, color: "text-orange-400" },
    { title: "Referral Income", value: stats.referralEarnings, icon: Gift, color: "text-red-400" }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.1 }}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
    >
      {cardData.map((card, index) => (
        <Card key={index} className="glass-effect border-white/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white/70">{card.title}</CardTitle>
            <card.icon className={`h-4 w-4 ${card.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">PKR {card.value.toLocaleString()}</div>
          </CardContent>
        </Card>
      ))}
    </motion.div>
  );
};

export default StatCards;