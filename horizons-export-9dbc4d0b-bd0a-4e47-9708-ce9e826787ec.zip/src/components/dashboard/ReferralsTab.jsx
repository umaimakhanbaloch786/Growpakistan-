import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Copy } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ReferralNode = ({ user, allUsers, level }) => {
  const referrals = allUsers.filter(u => u.referredBy === user.referralCode);
  return (
    <div className="tree-node">
      <div className="tree-leaf relative bg-white/5 p-2 rounded mb-2">
        <p className="text-white font-medium">{user.name} <span className="text-xs text-white/50">(Level {level})</span></p>
      </div>
      {referrals.length > 0 && (
        <div className="pl-5 relative">
          <div className="tree-branch"></div>
          {referrals.map(ref => (
            <ReferralNode key={ref.id} user={ref} allUsers={allUsers} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
};

const ReferralsTab = ({ referralCode, referrals, allUsers }) => {
  const { toast } = useToast();
  
  const copyReferralLink = () => {
    const referralLink = `${window.location.origin}/register?ref=${referralCode}`;
    navigator.clipboard.writeText(referralLink);
    toast({ title: "Copied!", description: "Referral link copied to clipboard." });
  };

  const directReferrals = allUsers.filter(u => u.referredBy === referralCode);

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card className="glass-effect border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Users className="h-5 w-5 mr-2 text-red-400" />
            Your Referral Network
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-white/10 rounded-lg border border-white/20">
            <p className="text-2xl font-bold text-center text-orange-400">{referralCode}</p>
          </div>
          <Button onClick={copyReferralLink} className="w-full bg-red-600 hover:bg-red-700 text-white">
            <Copy className="h-4 w-4 mr-2" />
            Copy Referral Link
          </Button>
        </CardContent>
      </Card>

      <Card className="glass-effect border-white/20">
        <CardHeader>
          <CardTitle className="text-white">Referral Tree</CardTitle>
        </CardHeader>
        <CardContent className="max-h-96 overflow-y-auto scrollbar-hide">
          {directReferrals.length > 0 ? (
            directReferrals.map(ref => (
              <ReferralNode key={ref.id} user={ref} allUsers={allUsers} level={1} />
            ))
          ) : (
            <p className="text-white/60 text-center py-8">No referrals yet. Share your code to build your tree!</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ReferralsTab;