import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus } from 'lucide-react';
import { investmentPlans } from '@/lib/referral';
import { useToast } from '@/components/ui/use-toast';

const InvestTab = ({ onInvest }) => {
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [screenshot, setScreenshot] = useState(null);
  const { toast } = useToast();

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setScreenshot(null);
      toast({ title: "Invalid File", description: "Please select an image file.", variant: "destructive" });
    }
  };
  
  const handleInvestmentSubmit = () => {
    if (!selectedPlan) {
      toast({ title: "No Plan Selected", description: "Please select an investment plan.", variant: "destructive" });
      return;
    }
    if (!screenshot) {
      toast({ title: "No Screenshot", description: "Please upload a payment screenshot.", variant: "destructive" });
      return;
    }
    onInvest(selectedPlan, screenshot);
    setSelectedPlan(null);
    setScreenshot(null);
  };

  return (
    <Card className="glass-effect border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Plus className="h-5 w-5 mr-2 text-orange-400" />
          New Investment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-white/80 mb-4">Select an investment plan:</p>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3 mb-6">
          {investmentPlans.map(plan => (
            <Button
              key={plan}
              variant={selectedPlan === plan ? 'default' : 'outline'}
              className={`text-white font-bold ${selectedPlan === plan ? 'bg-orange-500 border-orange-500' : 'bg-white/10 border-white/20'}`}
              onClick={() => setSelectedPlan(plan)}
            >
              PKR {plan}
            </Button>
          ))}
        </div>

        {selectedPlan && (
          <Dialog>
            <DialogTrigger asChild>
              <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold">
                Invest PKR {selectedPlan}
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-effect border-white/20 text-white">
              <DialogHeader>
                <DialogTitle>Confirm Investment of PKR {selectedPlan}</DialogTitle>
                <DialogDescription className="text-white/70">
                  Please make payment to the accounts below and upload a screenshot of your transaction.
                </DialogDescription>
              </DialogHeader>
              <div className="grid md:grid-cols-2 gap-4 my-4">
                <div>
                    <p className="font-bold text-orange-400">JazzCash</p>
                    <p>Name: Maria Shaheen</p>
                    <p>Number: 03447230855</p>
                </div>
                <div>
                    <p className="font-bold text-blue-400">Easypaisa</p>
                    <p>Name: Muhammad Ishfaq</p>
                    <p>Number: 03401070881</p>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="screenshot">Upload Payment Screenshot</Label>
                <Input id="screenshot" type="file" accept="image/*" onChange={handleFileChange} className="bg-white/10 border-white/20"/>
              </div>
              {screenshot && <img-replace src={screenshot} alt="Payment screenshot preview" className="mt-2 rounded-md max-h-40 w-auto"/>}
              <Button onClick={handleInvestmentSubmit} disabled={!screenshot} className="w-full mt-4 bg-green-500 hover:bg-green-600">
                Submit for Approval
              </Button>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
};

export default InvestTab;