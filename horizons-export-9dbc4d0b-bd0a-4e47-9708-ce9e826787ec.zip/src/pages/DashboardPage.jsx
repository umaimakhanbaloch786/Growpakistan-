import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import StatCards from '@/components/dashboard/StatCards';
import InvestTab from '@/components/dashboard/InvestTab';
import WithdrawTab from '@/components/dashboard/WithdrawTab';
import ReferralsTab from '@/components/dashboard/ReferralsTab';
import HistoryTab from '@/components/dashboard/HistoryTab';

const DashboardPage = () => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [allUsers, setAllUsers] = useState([]);

  const loadData = () => {
    if (!user) return;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const currentUser = users.find(u => u.id === user.id);
    if (currentUser) {
      setUserData(currentUser);
      setAllUsers(users);
    } else {
      logout();
      navigate('/login');
    }
  };

  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else {
      loadData();
    }
  }, [user, navigate]);

  const handleInvestment = (amount, screenshot) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.id === userData.id);

    if (userIndex !== -1) {
      const newInvestment = {
        id: Date.now().toString(),
        amount: amount,
        screenshot: screenshot,
        date: new Date().toISOString(),
        status: 'pending',
        plan: 0, // This is a fake daily ROI, as it's not specified
      };

      users[userIndex].investments.push(newInvestment);
      
      localStorage.setItem('users', JSON.stringify(users));
      loadData();
      
      toast({
        title: "Investment Submitted!",
        description: `Your investment of PKR ${amount} is pending admin approval.`,
      });
    }
  };

  const handleWithdrawal = (amount, method) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.id === userData.id);

    if (userIndex !== -1) {
      const newWithdrawal = {
        id: Date.now().toString(),
        amount: amount,
        method: method,
        date: new Date().toISOString(),
        status: 'pending'
      };
      
      users[userIndex].withdrawals.push(newWithdrawal);
      users[userIndex].currentBalance -= amount;
      
      localStorage.setItem('users', JSON.stringify(users));
      loadData();
      
      toast({
        title: "Withdrawal Requested!",
        description: `Your withdrawal of PKR ${amount} is pending approval.`,
      });
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  if (!userData) {
    return <div className="min-h-screen flex items-center justify-center text-white">Loading Dashboard...</div>;
  }

  const dashboardStats = {
    currentBalance: userData.currentBalance || 0,
    currentIncome: userData.currentIncome || 0,
    totalEarnings: userData.totalEarnings || 0,
    referralEarnings: userData.referralEarnings || 0,
  };

  return (
    <div className="min-h-screen p-4">
      <Helmet>
        <title>Dashboard - Grow Pakistan</title>
        <meta name="description" content="Manage your investments, track earnings, and grow your network on the Grow Pakistan dashboard." />
      </Helmet>

      <div className="container mx-auto max-w-6xl">
        <DashboardHeader userName={userData.name} onLogout={handleLogout} />
        <StatCards stats={dashboardStats} />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Tabs defaultValue="invest" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 bg-white/10 border border-white/20">
              <TabsTrigger value="invest" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Invest</TabsTrigger>
              <TabsTrigger value="withdraw" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Withdraw</TabsTrigger>
              <TabsTrigger value="referrals" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Referrals</TabsTrigger>
              <TabsTrigger value="history" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">History</TabsTrigger>
            </TabsList>
            <TabsContent value="invest"><InvestTab onInvest={handleInvestment} /></TabsContent>
            <TabsContent value="withdraw"><WithdrawTab currentBalance={userData.currentBalance} onWithdraw={handleWithdrawal} /></TabsContent>
            <TabsContent value="referrals"><ReferralsTab referralCode={userData.referralCode} referrals={userData.referrals} allUsers={allUsers} /></TabsContent>
            <TabsContent value="history"><HistoryTab investments={userData.investments} withdrawals={userData.withdrawals} /></TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
};

export default DashboardPage;