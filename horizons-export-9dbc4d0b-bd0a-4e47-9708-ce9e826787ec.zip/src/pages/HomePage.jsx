import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Users, Shield, DollarSign, ArrowRight, Star } from 'lucide-react';
import { investmentPlans } from '@/lib/referral';

const HomePage = () => {
  return (
    <div className="min-h-screen">
      <Helmet>
        <title>Grow Pakistan - Your Investment Partner</title>
        <meta name="description" content="Join Grow Pakistan to invest and grow your wealth. Secure investments with great referral bonuses. Start with just PKR 5." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="container mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white">
              Invest Today, <span className="gradient-text">Grow</span> Tomorrow with <span className="text-orange-400">Grow Pakistan</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 leading-relaxed">
              Unlock your financial potential with our secure investment plans and multi-level referral system.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="bg-orange-500 text-white hover:bg-orange-600 px-8 py-4 text-lg font-semibold">
                  Create Your Account
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 text-lg">
                  Access Your Dashboard
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Why Grow Pakistan?
            </h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto">
              We provide a transparent and powerful platform for everyone to build wealth.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: TrendingUp,
                title: "Flexible Plans",
                description: "Invest with as little as PKR 5 up to PKR 1000 with various options.",
                color: "text-orange-400"
              },
              {
                icon: Users,
                title: "Lucrative Referrals",
                description: "Earn through our deep 10-level referral system.",
                color: "text-blue-400"
              },
              {
                icon: Shield,
                title: "Secure & Transparent",
                description: "Admin-approved investments and transparent transaction history.",
                color: "text-red-500"
              },
              {
                icon: DollarSign,
                title: "Quick Withdrawals",
                description: "Minimum withdrawal of just PKR 3 to your favorite payment service.",
                color: "text-orange-300"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="glass-effect border-white/20 hover:border-white/40 transition-all duration-300 h-full">
                  <CardHeader className="text-center">
                    <feature.icon className={`h-12 w-12 mx-auto mb-4 ${feature.color}`} />
                    <CardTitle className="text-white text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-white/70 text-center">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Investment Plans */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our Investment Plans
            </h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto">
              A wide range of plans to suit every investor's needs.
            </p>
          </motion.div>

          <motion.div 
            className="flex flex-wrap justify-center gap-4"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, staggerChildren: 0.05 }}
          >
            {investmentPlans.sort((a,b) => a-b).map((plan, index) => (
              <motion.div
                key={index}
                className="bg-white/10 p-4 rounded-lg text-center font-bold text-white text-lg w-32 investment-card"
                whileHover={{ scale: 1.1 }}
              >
                PKR {plan}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

       {/* Payment Info Section */}
       <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
              Payment Information
            </h2>
            <div className="grid md:grid-cols-2 gap-8 text-white">
              <Card className="glass-effect border-white/20 p-6">
                <CardTitle className="text-2xl text-orange-400 mb-2">JazzCash</CardTitle>
                <p className="text-lg">Name: Maria Shaheen</p>
                <p className="text-lg">Number: 03447230855</p>
              </Card>
              <Card className="glass-effect border-white/20 p-6">
                <CardTitle className="text-2xl text-blue-400 mb-2">Easypaisa</CardTitle>
                <p className="text-lg">Name: Muhammad Ishfaq</p>
                <p className="text-lg">Number: 03401070881</p>
              </Card>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Ready to Join Grow Pakistan?
            </h2>
            <p className="text-xl text-white/80 mb-8">
              Sign up in seconds and start your journey towards financial growth.
            </p>
            <Link to="/register">
              <Button size="lg" className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold px-12 py-6 text-xl">
                Start Earning Now
                <ArrowRight className="ml-2 h-6 w-6" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;