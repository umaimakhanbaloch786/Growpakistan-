import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { processReferralBonuses } from '@/lib/referral';
import AdminHeader from '@/components/admin/AdminHeader';
import AdminStatCards from '@/components/admin/AdminStatCards';
import UsersTab from '@/components/admin/UsersTab';
import ActionableList from '@/components/admin/ActionableList';
import ReferralsTabAdmin from '@/components/admin/ReferralsTabAdmin';

const AdminDashboardPage = () => {
  const { isAdmin, logout } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalInvestments: 0,
    totalWithdrawals: 0,
    totalReferralBonuses: 0,
    adminEarnings: 0,
    pendingInvestments: 0,
    pendingWithdrawals: 0
  });

  const loadData = () => {
    const usersData = JSON.parse(localStorage.getItem('users') || '[]');
    setUsers(usersData);
    calculateStats(usersData);
  };
  
  useEffect(() => {
    if (!isAdmin) {
      navigate('/admin815');
      return;
    }
    loadData();
  }, [isAdmin, navigate]);

  const calculateStats = (usersData) => {
    const adminAccount = usersData.find(u => u.isAdminAccount === true);
    setStats({
      totalUsers: usersData.filter(u => !u.isAdminAccount).length,
      totalInvestments: usersData.reduce((sum, user) => sum + user.totalInvestment, 0),
      totalWithdrawals: usersData.reduce((sum, user) => 
        sum + user.withdrawals.filter(w => w.status === 'approved').reduce((wSum, w) => wSum + w.amount, 0), 0
      ),
      totalReferralBonuses: usersData.reduce((sum, user) => sum + user.referralEarnings, 0),
      adminEarnings: adminAccount ? adminAccount.adminEarnings || 0 : 0,
      pendingInvestments: usersData.reduce((sum, user) => sum + user.investments.filter(i => i.status === 'pending').length, 0),
      pendingWithdrawals: usersData.reduce((sum, user) => sum + user.withdrawals.filter(w => w.status === 'pending').length, 0)
    });
  };

  const handleInvestmentAction = (userId, investmentId, action) => {
    let usersData = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = usersData.findIndex(u => u.id === userId);
    
    if (userIndex !== -1) {
      const investmentIndex = usersData[userIndex].investments.findIndex(i => i.id === investmentId);
      
      if (investmentIndex !== -1) {
        usersData[userIndex].investments[investmentIndex].status = action;
        
        if (action === 'approved') {
          const investment = usersData[userIndex].investments[investmentIndex];
          usersData[userIndex].totalInvestment += investment.amount;
          
          usersData = processReferralBonuses(investment, usersData[userIndex], usersData);
        }
        
        localStorage.setItem('users', JSON.stringify(usersData));
        loadData();
        toast({ title: `Investment ${action}!` });
      }
    }
  };

  const handleWithdrawalAction = (userId, withdrawalId, action) => {
    const usersData = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = usersData.findIndex(u => u.id === userId);
    
    if (userIndex !== -1) {
      const withdrawalIndex = usersData[userIndex].withdrawals.findIndex(w => w.id === withdrawalId);
      
      if (withdrawalIndex !== -1) {
        usersData[userIndex].withdrawals[withdrawalIndex].status = action;
        
        if (action === 'rejected') {
          const withdrawal = usersData[userIndex].withdrawals[withdrawalIndex];
          usersData[userIndex].currentBalance += withdrawal.amount;
        }
        
        localStorage.setItem('users', JSON.stringify(usersData));
        loadData();
        toast({ title: `Withdrawal ${action}!` });
      }
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getAllItems = (type) => {
    return users
      .flatMap(user => 
        user[type].map(item => ({
          ...item,
          userName: user.name,
          userEmail: user.email,
          userId: user.id
        }))
      )
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  };
  
  if (!isAdmin) return null;

  return (
    <div className="min-h-screen p-4">
      <Helmet>
        <title>Admin Dashboard - Grow Pakistan</title>
        <meta name="description" content="Admin dashboard for managing Grow Pakistan." />
      </Helmet>

      <div className="container mx-auto max-w-7xl">
        <AdminHeader onLogout={handleLogout} />
        <AdminStatCards stats={stats} />

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/10 border border-white/20">
            <TabsTrigger value="users" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Users</TabsTrigger>
            <TabsTrigger value="investments" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Investments</TabsTrigger>
            <TabsTrigger value="withdrawals" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Withdrawals</TabsTrigger>
            <TabsTrigger value="referrals" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-900">Referrals</TabsTrigger>
          </TabsList>

          <TabsContent value="users"><UsersTab users={users.filter(u => !u.isAdminAccount)} /></TabsContent>
          
          <TabsContent value="investments">
            <Card className="glass-effect border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center"><ArrowUpRight className="h-5 w-5 mr-2 text-green-400" />Investment Management</CardTitle>
                <CardDescription className="text-white/70">Approve or reject investment requests.</CardDescription>
              </CardHeader>
              <CardContent><ActionableList items={getAllItems('investments')} type="investments" onAction={handleInvestmentAction} /></CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="withdrawals">
             <Card className="glass-effect border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center"><ArrowDownLeft className="h-5 w-5 mr-2 text-red-400" />Withdrawal Management</CardTitle>
                <CardDescription className="text-white/70">Approve or reject withdrawal requests.</CardDescription>
              </CardHeader>
              <CardContent><ActionableList items={getAllItems('withdrawals')} type="withdrawals" onAction={handleWithdrawalAction} /></CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="referrals"><ReferralsTabAdmin users={users.filter(u => !u.isAdminAccount)} /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboardPage;